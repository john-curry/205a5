import java.lang.Math;
public abstract class Filter {
  abstract int [][] ApplyFilter(int[][] image);
}
